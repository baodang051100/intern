export const REQ = 'REQ'
export const SUCCESS = 'SUCCESS'
export const ERROR = 'ERROR'
export const ADD_TEST = 'ADD_TEST'