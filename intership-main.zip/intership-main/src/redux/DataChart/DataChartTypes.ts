export const REQ = "REQ";
export const SUCCESS = "SUCCESS";
export const ERROR = "ERROR";

export const SUCCESSMONTH = "SUCCESSMONTH";

export const SUCCESSWEEK = "SUCCESSWEEK";
