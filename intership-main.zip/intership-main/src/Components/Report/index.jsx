import Listreport from './Listreport'
import './Report.css'
function Report(){
    return(
        <div className='listlevel'>
            <div className='listlevelright'>
                <Listreport/>
            </div>
        </div>
    )
}

export default Report;